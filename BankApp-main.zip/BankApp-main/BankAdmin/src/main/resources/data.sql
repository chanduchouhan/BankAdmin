insert into user_details(username,password,active,roles) values('admin','admin123',true,'ROLE_ADMIN')
insert into user_details(username,password,active,roles) values('user','user123',true,'ROLE_USER')
insert into user_details(username,password,active,roles) values('manager','manager123',true,'ROLE_MANAGER')
insert into user_details(username,password,active,roles) values('customer1','customer123',true,'ROLE_CUSTOMER')